package com.parvez.businessmanager

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.provider.OpenableColumns
import java.io.OutputStreamWriter
import android.graphics.Color
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 4102
    private val backupRequest = 4103
    private var pendingBackup: String = ""

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(93, 11, 37)
        window.navigationBarColor = Color.rgb(45, 8, 20)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(251, 247, 245))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.databaseEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveBackup(json: String) {
                pendingBackup = json
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "PARVEZ-business-backup.json")
                    }
                    startActivityForResult(intent, backupRequest)
                }
            }
        }, "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                return try { startActivityForResult(intent, fileRequest); true } catch (e: Exception) { fileCallback = null; false }
            }
        }
        web.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            try { startActivity(intent) } catch (_: Exception) { }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                if (url.scheme == "file" || url.scheme == "about") return false
                return true
            }
        }
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html") else web.restoreState(savedInstanceState)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == backupRequest) {
            if (resultCode == RESULT_OK && data?.data != null) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(pendingBackup.toByteArray(Charsets.UTF_8)) }
            }
            pendingBackup = ""
        } else if (requestCode == fileRequest) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
